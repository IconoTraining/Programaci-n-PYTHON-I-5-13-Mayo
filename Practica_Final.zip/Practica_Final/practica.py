import pandas as pd

# Crear un dataframe sobre el fichero de navegacion
dfNavegacion = pd.read_csv("navegacion.csv", sep=";")
#print(dfNavegacion.head(10))

''' *****************  Proceder a la limpia de datos  ****************** '''

# Comprobamos cuantos id_user repetidos hay
#print(dfNavegacion['id_user'].value_counts().head(50))

# Ver cuantos uuid repetidos hay
#print(dfNavegacion['uuid'].value_counts().head(50))

# Ver cuantos gclid repetidos hay
#print(dfNavegacion['gclid'].value_counts().head(50))

# Comprobar si los gclid repetidos corresponden al mismo usuario
#print(dfNavegacion.groupby(['gclid','id_user'])['ts'].count())

# El gclid= 0 tiene diferentes id_user lo considero un boot  y lo elimino
gclid0 = dfNavegacion[dfNavegacion['gclid'] == '0'].index
# tienen que salir 35 indices
#print(gclid0)
dfNavegacion = dfNavegacion.drop(gclid0)

gclid124 = dfNavegacion[dfNavegacion['gclid'] == 'EAIaIQobChMIwPu5t4qs3AIVAQAAAB0BAAAAEAAYACAAEgJVzfD_BwE'].index
# tienen que salir 124 indices
#print(gclid124)
dfNavegacion = dfNavegacion.drop(gclid124)

''' *****************  Procesar la informacion obtenida en la url  ****************** '''

# Filtrar para solo procesar las url no null
serieUrlLanding = dfNavegacion['url_landing'][dfNavegacion['url_landing'].notnull()]

# separar los parametros en nuevas columnas
#print(dfNavegacion.columns)
dfNavegacion[['url_base','idUser','uuid_url','camp','adg','device','sl','adv','rec','vacia']] = serieUrlLanding.str.split(pat='&',n=10,expand=True)
#print(dfNavegacion.columns)

# Elimino las columnas que no necesito
dfNavegacion = dfNavegacion.drop(['idUser', 'uuid_url', 'rec', 'vacia'], axis=1)
#print(dfNavegacion.columns)

#print(dfNavegacion['url_base'])


# url/modelo?parametros
dfNavegacion['url_base'] = dfNavegacion['url_base'].apply(lambda url: str(url).split('?')[0])
#print(dfNavegacion['url_base'])

# Obtener el modelo de coche
def obtenerModelo(url):
    posicion = url.rfind('/')
    modeloObtenido = url[posicion+1:]
    if modeloObtenido == '' or modeloObtenido == 'renting':
        modeloObtenido = 'home'
    return modeloObtenido

# crear una nueva columna modelo con el valor obtenido de la funcion anterior
dfNavegacion.insert(loc=7, column='modelo', value=dfNavegacion['url_base'].apply(obtenerModelo))
#print(dfNavegacion['modelo'].head(20))


''' ************************  Quedarnos con con los datos de cada usuario sin repetirlos ************************  '''
# Crear una columna llamada orden donde se guarda el orden de los id_user dependiendo del valor ts
dfNavegacion = dfNavegacion.sort_values(['id_user','ts'])
dfNavegacion.insert(loc=1, column='orden', value=dfNavegacion.groupby('id_user')['ts'].cumcount())

# Filtrar el dataframe para quedarme solo con orden=0
dfNavegacion = dfNavegacion[dfNavegacion['orden']==0]


''' ************************  Unimos el df de Navegacion con el df de Conversiones  '''
# crear el dataframe de conversiones
dfConversiones = pd.read_csv("conversiones.csv", sep=";")

# unir los dataframe a traves de id_user sin perder ningun dato
dfFinal = dfNavegacion.merge(dfConversiones,how='outer',on=['id_user'])


# Crear una nueva columna llamada conversiones: 1 (es conversion) (0 no lo es)
def esConversion(dato):
    lista = ['CALL', 'FORM']
    if dato in lista:
        return 1
    else:
        return 0


dfFinal.insert(loc=1, column='conversiones', value=dfFinal['lead_type'].apply(esConversion))


""" *****************************   PREGUNTAS A RESPONDER ***************************** """
# ¿Cuantas visitas recibe en el dia el cliente?
# creo la columna dia con la fecha de la columna ts
dfFinal.insert(loc=1, column='dia', value=dfFinal['ts'].apply(lambda ts: str(ts).split(' ')[0]))
print(dfFinal.groupby('dia')['dia'].count())   # 5640 el dia 6/9/2021 y 4 el dia 7

# ¿Cuantas converten y cuantas no en %?
#Filtrar solo 6/9/2021
visitas_dia_6_junio = dfFinal[dfFinal['dia'] == '2021-09-06']

# Cuanto las visitas de ese dia
num_visitas_dia = visitas_dia_6_junio['dia'].count()

# Cuento las visitas con conversion
visitas_convierten = visitas_dia_6_junio[visitas_dia_6_junio['conversiones'] == 1]['ts'].count()

# Cuento las visitas sin conversion
visitas_no_convierten = visitas_dia_6_junio[visitas_dia_6_junio['conversiones'] == 0]['ts'].count()
#print(num_visitas_dia, visitas_convierten, visitas_no_convierten)

# Calculo porcentajes
porcentaje_visitas_convierten = round((visitas_convierten / num_visitas_dia) * 100, 2)
print('convierten: ',porcentaje_visitas_convierten,'%')

porcentaje_visitas_no_convierten = round((visitas_no_convierten / num_visitas_dia) * 100, 2)
print('no convierten',porcentaje_visitas_no_convierten,'%')

# Por tipo de conversión (CALL o FORM), ¿cuántas hay de cada una?
print(dfFinal.groupby('lead_type')['lead_type'].count())

# Porcentaje de usuarios recurrentes sobre el total de usuarios
# En la variable total_usuarios cuento los usuarios a través de la columna id_user
total_usuarios = dfFinal['id_user'].count()

# Filtro el dataFrame por los usuarios recurrentes con valor true y que no sean nulos.
# Cuento los registros obtenidos a través de la columna ts y almaceno el resultado en usuarios_recurrentes
usuarios_recurrentes = dfFinal[dfFinal.user_recurrent & dfFinal.user_recurrent.notnull()]['ts'].count()

# Calculo el porcentaje y lo redondeo a 2 decimales
porcentaje = round((usuarios_recurrentes / total_usuarios) * 100, 2)
print(porcentaje, '%')


# Coche mas visitado
print(dfFinal['modelo'].value_counts())

# Es el que mas convierte?
# Voy a filtrar el dataset para tener solo los registros que han convertido y luego agruparlo
print(dfFinal[dfFinal['conversiones'] == 1].groupby('modelo')['conversiones'].count())

# pip install openpyxl
# exportar el dfFinal a Excel para poder elaborar informes, graficas, histogramas, ....etc
dfFinal.to_excel('dataframe_final.xlsx', index=False)