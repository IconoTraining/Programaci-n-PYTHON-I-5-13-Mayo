# Solicitar una letra (l,m,x,j,v,s,d) y decir a que dia corresponde
# El usuario puede escribirlo en mayuscula o minuscula

letra = input("Introduce letra del dia de la semana: ")

if letra == 'l' or 'L' :
    print("Es lunes")
elif letra.upper() == 'M' :
    print("Es martes")
elif letra.lower() == 'x' :
    print("Es miercoles")
elif letra.upper() == 'J':
    print("Es jueves")
elif letra.upper() == 'V' :
    print("Es viernes")
elif letra.lower() == 's' :
    print("Es sabado")
elif letra.lower() == 'd' :
    print("Es domingo")
else:
    print("Dia desconocido")
