# Solicitar una letra (l,m,x,j,v,s,d) y decir a que dia corresponde
# El usuario puede escribirlo en mayuscula o minuscula