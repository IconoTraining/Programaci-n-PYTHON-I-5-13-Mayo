# calcular los 50 primeros terminos de la serie de Fibonacci
# 0 1 1 2 3 5 8 13 .....

# declaracion multiple
#num1 = 0
#num2 = 1
num1, num2 = 0, 1
contador = 2
print(num1)

while (contador <= 50) :
    print(num2)
    num1, num2  = num2, num1 + num2
    contador += 1
print("---------- FIN ---------")