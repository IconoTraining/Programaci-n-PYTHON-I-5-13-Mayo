# Solicitar al usuario un numero entre 1 y 10
# Comprobar si es menor de 1
# comprobar si es mayor de 10
# Si es correcto mostrar "Correcto"

numero = int(input("Introduce numero entre 1 y 10: "))

# Version 1
if numero < 1 :
    print("El numero no puede ser menor que 1")
else:
    if numero > 10 :
        print("El numero no puede ser mayor que 10")
    else :
        print("Bieeen, me has hecho caso")
 
# Version 2       
if numero < 1 :
    print("El numero no puede ser menor que 1")
elif numero > 10 :
    print("El numero no puede ser mayor que 10")
else :
    print("Bieeen, me has hecho caso")