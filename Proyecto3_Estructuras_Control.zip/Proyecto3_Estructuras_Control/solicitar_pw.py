# Solicitar la pw al usuario hasta que acierte que es curso
# solo tiene 3 intentos

# Version 1
'''
pw = ""
intentos = 3
while pw != "curso" :
    pw = input("Introduce pw: ")
    intentos -= 1
    if intentos == 0 :
        print("Se agotaron tus oportunidades")
        break  # Damos por terminado el bucle
    
if pw == "curso" :
    print("Has acertado")
'''
    
# Version 2
'''
intentos = 0
while intentos < 3 :
    pw = input("Introduce pw: ")
    if pw == "curso" :
        print("Has acertado")
        break
    else:
        print("Incorrecta")
    intentos += 1
'''


# Version 3
password = "curso"
for intento in range(3) :
    pw = input("Introduce pw: ")
    if pw == password :
        print("Has acertado")
        break
    else :
        print("Contraseña incorrecta. Le quedan", 2-intento, "intentos")
        

# continue -> da por terminada esa iteraccion y pasa a la siguiente
# mostrar solo los numeros pares
for num in range(11) :
    if num % 2 != 0 :
        continue
    print(num)