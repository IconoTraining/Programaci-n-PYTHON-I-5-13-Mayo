import pandas as pd

# crear la serie a partir de una lista
data = ['Juan', 'Pedro', 'Estefania', 'Ana', 'Esteban']
serie = pd.Series(data, dtype="string")
print(serie)

print("longitud:",serie.size)

print("indices:",serie.index)

# acceder a un elemento por su indice
print(serie[2])

# aplicar funciones lamba
serie = serie.apply(lambda nombre: nombre.upper())
print(serie)

# filtrar serie
serie = serie[(serie == 'PEDRO') | (serie == 'JUAN')]
print(serie)