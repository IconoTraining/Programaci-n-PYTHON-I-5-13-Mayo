import pandas as pd

# crear el dataframe
data = [ ['Juan', 4.5], ['Pedro', 8.9], ['Estefania', 1.4], ['Ana', 5.6], ['Esteban', 7.8]]
columnasNombres = ['Nombre', 'Nota']
filas = list(range(5))
df = pd.DataFrame(data,columns=columnasNombres, index=filas)
print(df)

# obtener informacion
print("Info", df.info)
print("Shape", df.shape)
print("Size", df.size)
print("Nombres de las columnas", df.columns)
print("Nombres de indices", df.index)
print("solo 2 filas", df.head(2))


# acceder a los datos
print("Nota de Esteban", df.iloc[4,1])
print("Estefania", df.loc[2])
print("Notas", df['Nota'])

# Añadir una columna
resultado = ['Suspenso', 'Aprobado', 'Suspenso', 'Aprobado', 'Aprobado']
df.insert(loc=2, column="Resultado", value=resultado)
print(df)

# Añadir una fila
data = [['Maria', 4.5, 'Suspenso'], ['Antonio', 8.9, 'Aprobado']]
columnasNombres = ['Nombre','Nota','Resultado']
filas = [0,1]

otro_df = pd.DataFrame(data, columns=columnasNombres, index=filas)
otro_df = df.append(otro_df, ignore_index=True)
print(otro_df)

print(otro_df.groupby('Resultado').count())
