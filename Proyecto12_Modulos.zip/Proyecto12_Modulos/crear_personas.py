# Primera forma de importar el modulo
'''
import persona

# modulo.clase
p1 = persona.Persona("Juan", 27)
p1.mostrarInfo()
'''

# Segunda forma 
'''
from persona import Persona
p1 = Persona("Juan", 27)
p1.mostrarInfo()
'''

# Tercera forma
from persona import Persona as Person
p1 = Person("Juan", 27)
p1.mostrarInfo()