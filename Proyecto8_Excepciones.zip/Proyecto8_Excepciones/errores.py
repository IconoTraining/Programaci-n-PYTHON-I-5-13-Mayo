# try-except-else-finally

try:
    numero1 = int(input("Introduce dividendo: "))
    numero2 = int(input("Introduce divisor: "))
    division = numero1 / numero2
except ZeroDivisionError as error:
    print("Error, no se puede dividir por cero", error)
except ValueError as ex:
    print("El valor introducido no es numerico")
except Exception as ex:
    print("Ha ocurrido un error")
else:
    # se ejecuta solo cuando no hay errores o excepciones
    print("Resultado:", division)
finally:
    # se ejecuta siempre, haya o no excepciones
    print("***** FIN ****")