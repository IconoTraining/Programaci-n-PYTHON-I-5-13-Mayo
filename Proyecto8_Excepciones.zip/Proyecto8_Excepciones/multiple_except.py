# sumar los numeros

datos = ['1','dos','3','4','5']
suma = 0

for i in range(len(datos) + 1):

    try:
        # accedemos al dato
        dato = datos[i]
        
        # lo convertimos en numero
        numero = int(dato)
        
        
    except (ValueError, IndexError, Exception) as ex:
        print("Error de tipo", type(ex))
        print("Ha ocurrido un error", ex)
        
    else:
        # lo sumamos
        suma += numero
    
        
print("Suma:", suma)