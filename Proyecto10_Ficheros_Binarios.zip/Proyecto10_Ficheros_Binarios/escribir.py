import pickle

nombres = ['Juan', 'Pedro', 'Maria', 'Luis', 'Irene']
fichero = open("Proyecto10_Ficheros_Binarios/binario.pckl", "wb")
pickle.dump(nombres, fichero)
fichero.close()