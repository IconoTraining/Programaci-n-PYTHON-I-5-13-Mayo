import pickle

fichero = open("Proyecto10_Ficheros_Binarios/binario.pckl", "rb")
nombres = pickle.load(fichero)
print(nombres)
print(type(nombres))