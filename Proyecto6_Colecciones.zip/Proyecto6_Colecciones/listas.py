# listas: colecciones ordenadas de elementos
# Permite elementos duplicados
# Se crean con []

colores = ['rojo', 'verde', 'azul']
print(type(colores)) # list

# mostrar la lista
print(colores)

# ordenar la lista
print(sorted(colores))

# mostrar el color verde
print(colores[1])

# borrar el color azul
del colores[2] # borrar por posicion
print(colores)

# concatenar a otra lista
masColores = ['blanco', 'negro', 'rosa', 'azul']
nuevaLista = colores + masColores
print(nuevaLista)

# borrar el color rosa
nuevaLista.remove('rosa') # borrar por elemento
print(nuevaLista)

# otra forma de borrar por indice
nuevaLista.__delitem__(4)
print(nuevaLista)

# añadir un elemento al final
nuevaLista.append('naranja')
print(nuevaLista)

# insertar elemento en la primera posicion
nuevaLista.insert(0,'marron')
print(nuevaLista)

# contar cuantos colores verde hay
print(nuevaLista.count('verde'))

# mostrar el indice del color verde
print(nuevaLista.index('verde'))

# longitud de la lista
print(len(nuevaLista))
print(nuevaLista.__len__())

# mostrar el ultimo elemento
print(nuevaLista[len(nuevaLista) - 1])
print(nuevaLista[-1])

# mostrar el tercer elemento empezando por el final
print(nuevaLista[-3])

# mostrar los 3 ultimos elementos 
print(nuevaLista[-3:])

# mostrar todos los elementos
print(nuevaLista[:])

# mostrar elementos desde la posicion 2 hasta la 4 (ultimo excluido)
print(nuevaLista[2:4])

# mostrar desde -4 hasta -2 (ultimo excluido)
print(nuevaLista[-4:-2])

# siempre se recorre de izda a derecha. Esto no funciona, devuelve la lista vacia
print(nuevaLista[-2:-4])

# borrar todos los elementos de la lista
nuevaLista.clear()
print(len(nuevaLista))