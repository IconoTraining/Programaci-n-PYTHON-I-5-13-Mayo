# diccionarios: los elementos son key:value
# las claves no se pueden repetir pero los value si
# se crean con {}

# si repito la clave se sobreescribe el valor
alumnos = {"Juan":6.4, "Maria": 8.3, "Luis": 6.4, "Adolfo":7.1, "Maria":9.3}
print(type(alumnos))
print(alumnos)

# mostrar solo las claves
print(alumnos.keys())
print(type(alumnos.keys()))

# mostrar las claves ordenadas
print(sorted(alumnos.keys()))

# mostrar solo los values
print(alumnos.values())

# Mostrar si Maria esta en alumnos
print("Maria" in alumnos)

# Acceder a un elemento por su clave
print(alumnos.get('Luis'))
print(alumnos['Luis'])

# Eliminar a Adolfo
del alumnos['Adolfo']
print(alumnos)

# Agregar a Pedro
alumnos['Pedro'] = 4.7
print(alumnos)

# Recorrer un diccionario
for alum in alumnos: # solo me devuelve las keys
    print(alum, alumnos[alum])
    
for clave, valor in alumnos.items():
    print(clave, valor)
    
for item in alumnos.items():
    print(item)
    
# otras formas de como crear diccionarios
otro = dict( [ ("Luis",8.9), ("Maria",6.3), ("Adolfo",6.9) ] )
otroMas = dict(Luis=8.9, Maria=6.3, Adolfo=6.9)

print(otro)
print(otroMas)