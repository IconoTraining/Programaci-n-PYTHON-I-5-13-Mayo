# conjuntos: coleccion sin orden
# No se garantiza el orden de entrada
# No permite elementos duplicados, los ignora
# Al igual del resto de colecciones permite elementos de diferente tipo
# Se crean con {}

frutas = {'manzana','naranja','pera','naranja','platano'}
print(type(frutas)) # set

print(frutas)

# comprobar si tengo fresas
print('fresas' in frutas)

# comprobar si tengo pera
print('pera' in frutas)

# agregar fresas
frutas.add('fresas')
print(frutas)

# eliminar platano
frutas.remove('platano')
print(frutas)

# mostrar la longitud
print(len(frutas))
print(frutas.__len__())

numeros1 = {1,2,3,4,5,6,7,8,9}
numeros2 = {0,2,4,6,8,10}

# interseccion de conjuntos: elementos comunes en ambos
print(numeros1.intersection(numeros2))
print(numeros1 & numeros2)

# mostrar los elementos de numeros1 que no estan en numero2
print(numeros1.difference(numeros2))
print(numeros1 - numeros2)

# lo mismo pero al reves
print(numeros2.difference(numeros1))
print(numeros2 - numeros1)

# que elementos estan fuera de las intersecciones
print(numeros1.symmetric_difference(numeros2))
print(numeros1 ^ numeros2)

# borra los elementos de numeros1 que esten en  numeros2
numeros1.difference_update(numeros2)
print(numeros1)
print(numeros2)

''' compresion de listas  '''
def filtrar():
    y = set()  # llamo al constructor de set
    for letra in 'abracadabra':
        if letra not in 'abc':
            y.add(letra)
    return y

x = filtrar()
print(x)

# Esto lo puedo hacer en una sola linea
resultado = {letra for letra in 'abracadabra' if letra not in 'abc' }
print(resultado)
