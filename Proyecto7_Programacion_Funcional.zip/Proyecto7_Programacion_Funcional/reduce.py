# La funcion reduce le pasamos una coleccion y
# retorna un solo resultado
# la funcion debe recibir 2 parametros
#       - el primero actua como acumulador
#       - el segundo es el valor recibido
# sintaxis:    reduce(funcion, coleccion)

''' Para utilizar reduce es necesario importarlo  '''
from functools import reduce

# Ejemplo 1
numeros = [3,8,4,15,30]

def sumar(resultado, num):
    return resultado + num

print("Suma: ", reduce(sumar, numeros))


# Ejemplo 2
colores = ['rojo', 'verde', 'azul']

def concatenar(resultado, color) :
    return resultado.upper() + "-" + color.upper()

print(reduce(concatenar, colores))