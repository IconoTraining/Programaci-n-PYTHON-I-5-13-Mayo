'''
    Ejemplo de tipos basicos en Python
'''

# numeros enteros -> int
numero1 = 5
numero2 = 3
suma = numero1 + numero2
print(type(suma))
print("Suma: " + str(suma))  # concatenar en python es complicado
print("Suma:", suma)

# numeros reales -> float
base = 5.78
altura = 9.23
triangulo = base * altura / 2
print(type(triangulo))
print("Area triangulo:", triangulo)

# cadenas de texto -> str
# se pueden utilizar con comillas dobles o simples
nombre = "Pepito"
apellido = 'Perez'
print(type(nombre))
print(nombre, apellido)

# booleanos -> bool
# solo admite: True y False
pagado = True
print(type(pagado))
print("Esta pagado?", pagado)