# convertir un texto a numero entero
dato = input("Introduce un numero: ")
print(type(dato))
numero = int(dato)
print(type(numero))

# convertir un texto a numero real
altura = float(input("Dime cuanto mides: "))
print(type(altura))

# convertir a texto
texto = str(altura)
print(type(texto))


# Redondear un numero
# round(que, cuantos_decimales)
print( round(37.76556788, 2))   # 2 decimales