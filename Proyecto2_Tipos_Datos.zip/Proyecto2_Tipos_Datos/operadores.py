# Operadores aritmeticos (+, -, *, /, %, **, //)
numero1 = 7
numero2 = 5
print("Suma:", numero1 + numero2)
print("Resta:", numero1 - numero2)
print("Multiplicacion:", numero1 * numero2)
print("Division:", numero1 / numero2)
print("Resto:", numero1 % numero2)
print("Potencia:", numero1 ** numero2)
print("Division entera:", numero1 // numero2)

# Operadores asignacion (+=, -=, *=, /=, %=, **=, //=)
numero1 = numero1 + 1
numero1 += 1
print(numero1)


# En Python no existe incrementos y decrementos
# numero++ 

# Operadores de comparacion (<, >, <=, >=, ==, !=)
print("Menor:", numero1 < numero2)
print("Igual:", numero1 == numero2)
print("Diferente:", numero1 != numero2)

# Operadores logicos (and, or, not)
print("not:", not(numero1 < numero2))
print("and:", (numero1 < numero2) and (numero2 == 5))
print("or:", (numero1 < numero2) or (numero2 == 5))

# Operadores de identidad (is, is not)
num1 = 6
num2 = 6
print("Mismo contenido?", num1 is num2) # True porque la variable contiene el numero

nombres1 = ['Juan', 'Maria']
nombres2 = ['Juan', 'Maria']
print("Mismo contenido?", nombres1 is nombres2) # False porque los objetos son diferentes

name1 = 'Jorge'
name2 = 'Jorge'
print("Mismo contenido?", name1 is name2) # True porque los str en Python son tipos basicos

# Operadores de pertenencia (in, in not)
print("in", 'Luis' in nombres1)
print("in", 'Maria' in nombres1)
print("not in", 'Luis' not in nombres1)