texto = "Bienvenid@s al curso de Python"
print(texto)

print(texto.capitalize())
print(texto.upper())
print(texto.lower())
print("Isalnum:", texto.isalnum()) # los espacios en blanco no son alfanumericos
print("Isalpha:", texto.isalpha()) 
print("Isdigit:", texto.isdigit()) 
print("Islower:", texto.islower()) 
print("Isupper:", texto.isupper()) 

ejemplo="    lunes    "
print(ejemplo, end=".\n")
print("lstrip", ejemplo.lstrip(), end=".\n")
print("rstrip", ejemplo.rstrip(), end=".\n")
print("strip", ejemplo.strip(), end=".\n")

print("longitud:", len(texto))
print("Max:", max(texto))
print("Min:", min(texto))

print("replace:", texto.replace('e','E'))

print("split:", texto.split())  # por defecto parte por el espacio en blanco
print("split:", "5/5/2022".split('/'))
datos = "5/5/2022".split('/')
print("dia:", datos[0])
print("mes:", datos[1])
print("año:", datos[2])

print(texto.swapcase())