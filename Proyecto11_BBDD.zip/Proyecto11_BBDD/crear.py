''' 
    En este archivo creamos la estructura de la BBDD
'''

import sqlite3

# crear la BBDD
# abrir la bbdd si no existe la crea
conexion = sqlite3.connect("tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

# Crear la tabla
sql = "CREATE TABLE PRODUCTOS (codigo INTEGER PRIMARY KEY, descripcion TEXT, precio REAL)"
cursor.execute(sql)

# importante hacer el commit
conexion.commit()

# cerrar la conexion
conexion.close()