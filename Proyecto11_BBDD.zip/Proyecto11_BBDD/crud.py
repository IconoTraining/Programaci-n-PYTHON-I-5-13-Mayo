# CRUD
# C -> Create
# R -> Read
# U -> Update
# D -> Delete

import sqlite3

# abrir una conexion a la BBDD
conexion = sqlite3.connect("tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

'''  *********************   Insertar datos   ******************  '''
# insertar un registro
#cursor.execute("INSERT INTO PRODUCTOS values (1, 'Pantalla 17 pulgadas', 89.95) ")
cursor.execute("INSERT INTO PRODUCTOS (codigo, descripcion) values (1, 'Pantalla 17 pulgadas') ")

# insertar varios registros a la vez
lista = [ (2, 'Teclado', 29.50), (3, 'Raton', 15.0), (4, 'Impresora', 120.80) ]
sql = "INSERT INTO PRODUCTOS values (?,?,?)"
#cursor.executemany(sql, lista)

# importante hacer commit
conexion.commit()


''' **********************   Consultar todos *******************  '''
cursor.execute("select * from PRODUCTOS")

# recoger los resultados obtenidos
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("------ FIN ------ ")


''' **********************   Consultar precio sea menor a 50€ *******************  '''
cursor.execute("select * from PRODUCTOS where precio < 50")

# recoger los resultados obtenidos
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("------ FIN ------ ")


''' **********************   Consultar productos ordenados por descripcion *******************  '''
cursor.execute("select * from PRODUCTOS order by descripcion ")

# recoger los resultados obtenidos
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("------ FIN ------ ")

''' **********************   Consultar productos cuya descripcion comience por R *******************  '''
cursor.execute("select * from PRODUCTOS where descripcion LIKE 'R%' ")

# recoger los resultados obtenidos
productos = cursor.fetchall()
for prod in productos:
    print(prod)
print("------ FIN ------ ")


''' **********************   Modificar el precio de la impresora  ********************* '''
cursor.execute("UPDATE PRODUCTOS SET precio=110.50 where descripcion = 'Impresora' ")

# importante hacer commit
conexion.commit()


''' **********************   Eliminar la pantalla  *********************'''
cursor.execute("DELETE FROM PRODUCTOS where codigo = 1")

# importante hacer commit
conexion.commit()

# cerrar la conexion
conexion.close()