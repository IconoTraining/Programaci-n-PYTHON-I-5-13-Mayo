# declarar funciones
def saludar(nombre):
    print("Hola", nombre, "que bien que es viernes")
    
def despedir() :
    return "Adios, nos vemos el lunes"
    
# invocar o llamar a una funcion
saludar("Pepito")
mensaje = despedir()
print(mensaje)

print(despedir())