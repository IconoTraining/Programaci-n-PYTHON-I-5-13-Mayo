# crear una funcion que recibe un texto y devuelve 3 datos:
# El texto en mayusculas
# El texto en minusculas
# La longitud del texto

def procesarTexto(texto):
    mayusculas = texto.upper()
    minusculas = texto.lower()
    longitud = len(texto)
    return mayusculas, minusculas, longitud

# recuperamos con multiples variables
txtMay, txtMin, txtLen = procesarTexto("Hola, que tal?")
print(txtMay)
print(txtMin)
print(txtLen)

# recuperar con una lista
lista = procesarTexto("Hola, que tal?")
print(lista)
for dato in lista :
    print(dato)