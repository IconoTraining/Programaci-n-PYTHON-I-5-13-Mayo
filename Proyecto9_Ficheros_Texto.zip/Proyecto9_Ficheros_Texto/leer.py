# abrir el fichero en modo lectura
fichero = open("Proyecto9_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# leer todo el contenido
texto = fichero.read()
print(texto)

# mover el puntero al primer caracter
fichero.seek(0)

# solo quiero leer la primera linea
linea = fichero.readline()
print(linea)

# Leer todas las lineas y las proceso una por una
fichero.seek(0)
lineas = fichero.readlines()
for linea in lineas:
    print(linea, end="")
print()

# Crear una lista con el contenido del fichero
# Cada linea sea un elemento de la lista
fichero.seek(0)
lista = list(fichero)
print(lista)

# cerrar el fichero
fichero.close()