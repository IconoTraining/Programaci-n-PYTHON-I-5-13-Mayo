# abrir el fichero en modo escritura respetando el contenido existente
fichero = open("Proyecto9_Ficheros_Texto/fichero.txt", "at", encoding="utf-8")

texto = "\nEsto es una prueba"
fichero.write(texto)

# cerrar el fichero
fichero.close()