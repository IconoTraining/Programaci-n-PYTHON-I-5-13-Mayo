'''
    abrir el fichero de lectura, el fichero de escritura
    leer y escribir

'''