'''
    abrir el fichero de lectura, el fichero de escritura
    leer y escribir
'''

# abrir el fichero de lectura
ficheroRead = open("Proyecto9_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# abrir el fichero de escritura
# a+ -> abro el fichero en modo lectura-escritura
ficheroWrite = open("Proyecto9_Ficheros_Texto/fichero_escritura.txt", "a+", encoding="utf-8")

# leer  el contenido del fichero
contenido = list(ficheroRead)

# escribir cada linea
for linea in contenido:
    ficheroWrite.write(linea)
    
# leer el contenido creado
ficheroWrite.seek(0)
for linea in ficheroWrite.readlines():
    print(linea, end="")
print()

# cerrar los ficheros
ficheroRead.close()
ficheroWrite.close()

