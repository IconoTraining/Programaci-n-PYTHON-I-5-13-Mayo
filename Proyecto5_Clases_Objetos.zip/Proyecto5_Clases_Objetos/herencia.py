class Vehiculo:
    
    def __init__(self, motor, velocidad):
        self.__motor = motor # True o False
        self.__velocidad = velocidad
        
    def isMotor(self):
        return self.__motor
    
    def getVelocidad(self):
        return self.__velocidad
    
    def arrancar(self):
        print("Arrancando el vehiculo")
        
    def parar(self):
        print("Parando el vehiculo")
        
    def info(self):
        return "Tiene motor: " + str(self.__motor) + " Velocidad: " + str(self.__velocidad)
  
    
class Coche(Vehiculo):
    
    def __init__(self, motor, velocidad, plazas, combustible):
        super().__init__(motor, velocidad)
        self.__plazas = plazas
        self.__combustible = combustible
        
    def getPlazas(self):
        return self.__plazas
    
    def getCombustible(self):
        return self.__combustible
    
    def repostar(self):
        print("El coche necesita repostar")
        
    def info(self):
        return super().info() + " Plazas: " + str(self.__plazas) + " Combustible: " + self.__combustible
    
    
# Crear un coche
coche = Coche(True, 200, 5, "Gasolina")
print(coche.info())
coche.repostar()
coche.arrancar()
coche.parar()