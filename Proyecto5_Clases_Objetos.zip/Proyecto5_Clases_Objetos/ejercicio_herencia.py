class Figura:
    
    def __init__(self, coordenadaX, coordenadaY) :
        self.__coordenadaX = coordenadaX
        self.__coordenadaY = coordenadaY
        
    def getCoordenadaX(self):
        return self.__coordenadaX
    
    def setCoordenadaX(self, coordenadaX):
        self.__coordenadaX = coordenadaX
    
    def getCoordenadaY(self):
        return self.__coordenadaY
    
    def setCoordenadaY(self, coordenadaY):
        self.__coordenadaY = coordenadaY
        
    def posicion(self):
        # [5,3]
        return "[" + str(self.__coordenadaX) + "," + str(self.__coordenadaY) + "]" 
    

class Circulo(Figura):
    def __init__(self, coordenadaX, coordenadaY, radio) :
        super().__init__(coordenadaX, coordenadaY)
        self.__radio = radio
        
    def getRadio(self):
        return self.__radio
    
    def setRadio(self, radio):
        self.__radio = radio
        
    def posicion(self):
        # [5,3] con radio 9
        return super().posicion() + " con radio " + str(self.__radio)
    

class Rectangulo(Figura):
    def __init__(self, coordenadaX, coordenadaY, base, altura):
        super().__init__(coordenadaX, coordenadaY)
        self.__base = base
        self.__altura = altura
        
    def getBase(self):
        return self.__base
    
    def setBase(self, base):
        self.__base = base
        
    def getAltura(self):
        return self.__altura
    
    def setAltura(self, altura):
        self.__altura = altura
        
    def posicion(self):
        # [5,3] con radio 9
        return super().posicion() + " con base " + str(self.__base) + " y altura " + str(self.__altura)
    
    
# Crear una instancia de cada clase
figura = Figura(5,7)
circulo = Circulo(6,2,9)
rectangulo = Rectangulo(8,1,6,7)

print(figura.posicion())
print(circulo.posicion())
print(rectangulo.posicion())