'''
    Una clase encapsulada tiene todas sus propiedades o atributos privados y
    se accede a ellos a través de métodos get y set publicos
'''

class Fecha:
    def __init__(self, dia, mes, anyo):
        self.setDia(dia)
        self.setMes(mes)
        self.setAnyo(anyo)
    
    def getDia(self):
        return self.__dia
    
    def setDia(self, dia):
        # los dias son entre 1 y 30
        if dia > 0 and dia <= 30 :
            self.__dia = dia
        else :
            self.__dia = 0
            
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        # los meses son entre 1 y 12
        if mes > 0 and mes <= 12 :
            self.__mes = mes
        else :
            self.__mes = 0
            
    def getAnyo(self):
        return self.__anyo
    
    def setAnyo(self, anyo):
        # Año valido si es 2022 y 2023
        if anyo == 2022 or anyo == 2023 :
            self.__anyo = anyo
        else :
            self.__anyo = 0
            
    def mostrar(self):
        print(self.__dia, self.getMes(), self.__anyo, sep="/")
            

# Crear fechas
hoy = Fecha(9, 5, 2022)
hoy.mostrar()

otra = Fecha(-777, 67, 12)
otra.mostrar()
